FrameDoctor example project

Unreal Engine 5.5 / 5.6 / 5.7 / 5.8, Windows (Win64).
Contains one optional exploratory Blueprint scenario.
Requires FrameDoctor; the plugin is not included.

1. Install FrameDoctor for your engine version. Installing it to the engine
   from Fab is recommended. A source installation requires that engine's
   matching C++ toolchain, including for Blueprint-only projects.

2. Extract the ZIP and open FrameDoctorExample.uproject. It is associated
   with UE 5.5. For UE 5.6, 5.7 or 5.8, right-click the .uproject, choose
   Switch Unreal Engine version, and select your engine first. Keep a
   separate copy if you need to return to an older engine.

3. Enable FrameDoctor in Edit > Plugins and restart Unreal if requested.

4. Open and save a map, then press Play. Open Tools > FrameDoctor > Capture.
   Leave the packaged Development build option unchecked. In Scenario,
   select BP_ExploratoryScenario. Its asset is in:
   Content > FrameDoctorExample > Scenarios

5. Click Capture running PIE. Keep Play running until warmup and measurement
   finish, then open Findings to inspect the captured CPU evidence.

The project initially opens the engine's minimal Entry map. It contains
no benchmark scene or artificial optimization result. This exploratory
scenario has no declared repeatable workload and cannot confirm an A/B
effect. Create your own repeatable scenario for confirming comparisons.

To use the Blueprint in another project, right-click it in the Content
Browser, choose Asset Actions > Migrate, and select that project's Content
folder. FrameDoctor must also be enabled there.

Scenario class path:
/Game/FrameDoctorExample/Scenarios/BP_ExploratoryScenario.BP_ExploratoryScenario_C

Documentation: https://nexusforgeue.github.io/FrameDoctor-docs/
