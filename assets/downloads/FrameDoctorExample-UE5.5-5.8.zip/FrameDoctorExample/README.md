# FrameDoctor example project

This small, optional project contains one exploratory Blueprint scenario for FrameDoctor. The FrameDoctor plugin is required and is not included. Use Unreal Engine 5.5, 5.6, 5.7 or 5.8.

1. Install the matching FrameDoctor plugin from Fab into your Unreal Engine installation. If you install the plugin from source instead, use the C++ toolchain required by that engine, including for this Blueprint-only project.
2. Extract the ZIP to a normal folder. Open `FrameDoctorExample.uproject`. Its default engine association is 5.5. To open it with 5.6, 5.7 or 5.8, right-click the file, choose **Switch Unreal Engine version**, and select the matching installation before opening it. Save a separate project copy if you need to return to an older engine.
3. In Unreal, open **Edit > Plugins**, find FrameDoctor, and confirm that it is enabled. Restart the editor if asked.
4. Open **Tools > FrameDoctor**, then **Capture**. Use PIE mode and select `BP_ExploratoryScenario` as the scenario. The asset is in **Content > FrameDoctorExample > Scenarios**, with class path `/Game/FrameDoctorExample/Scenarios/BP_ExploratoryScenario.BP_ExploratoryScenario_C`.
5. Press **Play** to start PIE, then start the capture in FrameDoctor. Wait for the warmup and measurement to finish. Use **Findings** to inspect the captured CPU evidence.

The project opens the engine's minimal Entry map. It demonstrates scenario selection and an exploratory capture; it contains no benchmark scene or artificial optimization result. The exploratory scenario does not declare a repeatable workload and cannot produce a confirming A/B verdict. Create your own repeatable scenario and declared conditions for confirming comparisons.

To use this scenario in your own project, find the Blueprint in the Content Browser, right-click it, and choose **Asset Actions > Migrate**. Select your project's **Content** folder. Enable FrameDoctor in the destination project as well.

Documentation: https://nexusforgeue.github.io/FrameDoctor-docs/
